from gw.actor import Actor


class Flower(Actor):
    def __init__(self, location, grid):
        Actor.__init__(self, location, grid, icon="gw/car.png")

    def act(self):
        pass
