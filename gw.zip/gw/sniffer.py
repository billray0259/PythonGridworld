from gw.robot import Robot
import random
from gw.smelly_man import SmellyMan
import math
import pygame

class Sniffer(Robot):
    def __init__(self, location, grid, instructions="hillclimb_instructions.txt", smell_strength = 1.0, target_class = SmellyMan):
        Robot.__init__(self, location, grid, instructions=instructions, smell_strength=smell_strength)
        self.target_class = str(target_class)

    def act(self):
        if not self.user_controlled:
            self.variables["step"] = self.grid.step
            # next_action() will read through the instructions text file and run code until it reaches
            # an action that the robot should take such as 'forward' or 'turn left'
            action = self.main_loop.next_action()
            self.location.row = round(self.variables["row"])
            self.location.col = round(self.variables["col"])
            # Execute the action
            if action == "forward":
                if self.can_move(self.direction):
                    self.forward()
            elif action == "backward":
                if self.can_move(self.direction + 180):
                    self.move_to(self.get_location_in_direction(self.direction + 180))
                else:
                    print("Blocked!")
            elif action == "turn right":
                self.turn_right()
            elif action == "turn left":
                self.turn_left()
            elif action == "user input":
                self.user_controlled = True
            elif action == "hillclimb":
                adj_locs = self.get_empty_adjacent_locations()
                random.shuffle(adj_locs)
                max_smell = 0
                smelliest_loc = None
                for loc in adj_locs:
                    smell = self.grid.smells[self.target_class][loc.row][loc.col]
                    if (smell == max_smell and random.random() < 0.5) or smell > max_smell:
                        max_smell = smell
                        smelliest_loc = loc
                if smelliest_loc is not None:
                    self.direction = self.get_direction_towards(smelliest_loc)
                    self.move_to(smelliest_loc)
            elif action is None:
                pass
            else:
                print("Unknown action: " + action)
        else:
            pressed_keys = pygame.key.get_pressed()
            if pressed_keys[pygame.K_w] and self.can_move(self.direction):
                self.forward()
            elif pressed_keys[pygame.K_s] and self.can_move(self.direction + 180):
                self.move_to(self.get_location_in_direction(self.direction + 180))
            elif pressed_keys[pygame.K_a]:
                self.turn_left()
            elif pressed_keys[pygame.K_d]:
                self.turn_right()
