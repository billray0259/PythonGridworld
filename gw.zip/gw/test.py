print("test".strip())
print (" test")
